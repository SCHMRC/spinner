import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-from-file',
  templateUrl: './from-file.component.html',
  styleUrls: ['./from-file.component.scss']
})
export class FromFileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
