import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-from-deisy',
  templateUrl: './from-deisy.component.html',
  styleUrls: ['./from-deisy.component.scss']
})
export class FromDeisyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
